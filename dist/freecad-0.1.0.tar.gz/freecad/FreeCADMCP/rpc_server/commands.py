"""Qt Command classes for the MCP Addon workbench menu.

Defines six toolbar/menu entries (Start, Stop, Toggle Auto-Start,
Toggle Remote, Configure Allowed IPs, Set Auth Token).

``register_commands()`` and ``schedule_toggle_sync()`` are invoked from
``rpc_server.py`` at import time to preserve current side-effect behavior.
"""

import FreeCAD
import FreeCADGui
from PySide import QtWidgets
from typing import Any

from rpc_server.ip_filter import validate_allowed_ips
from rpc_server.settings import load_settings, save_settings


def _report_server_command(message: str, error: bool = False) -> None:
    """Show command feedback even when the Report View is closed."""
    printer = FreeCAD.Console.PrintError if error else FreeCAD.Console.PrintMessage
    printer(message + "\n")
    try:
        FreeCADGui.getMainWindow().statusBar().showMessage(message, 15000)
    except Exception:
        # Console feedback remains available if the main window is closing.
        pass


def _persist_settings(settings: dict[str, Any]) -> bool:
    try:
        save_settings(settings)
    except Exception as exc:
        _report_server_command(f"Settings were not saved: {exc}", error=True)
        return False
    return True


class StartRPCServerCommand:
    def GetResources(self):
        return {"MenuText": "Start RPC Server", "ToolTip": "Start RPC Server"}

    def Activated(self, checked: int = 0) -> None:
        try:
            from . import rpc_server  # late import: avoids circular at module load
            msg = rpc_server.start_rpc_server()
        except Exception as exc:
            _report_server_command(f"RPC Server failed to start: {type(exc).__name__}: {exc}", error=True)
            return
        _report_server_command(msg)

    def IsActive(self):
        return True


class StopRPCServerCommand:
    def GetResources(self):
        return {"MenuText": "Stop RPC Server", "ToolTip": "Stop RPC Server"}

    def Activated(self, checked: int = 0) -> None:
        try:
            from . import rpc_server
            msg = rpc_server.stop_rpc_server()
        except Exception as exc:
            _report_server_command(f"RPC Server failed to stop: {type(exc).__name__}: {exc}", error=True)
            return
        _report_server_command(msg)

    def IsActive(self):
        return True


class ToggleRemoteConnectionsCommand:
    def GetResources(self):
        settings = load_settings()
        return {
            "MenuText": "Remote Connections",
            "ToolTip": "Enable or disable remote connections for the RPC server.",
            "Checkable": bool(settings.get("remote_enabled", False)),
        }

    def Activated(self, checked=0):
        from . import rpc_server
        settings = load_settings()
        settings["remote_enabled"] = bool(checked)
        if not _persist_settings(settings):
            return

        if settings["remote_enabled"]:
            allowed_ips = settings.get("allowed_ips", "127.0.0.1")
            FreeCAD.Console.PrintMessage(
                f"Remote connections enabled. Allowed IPs: {allowed_ips}\n"
            )
            if not settings.get("auth_token", ""):
                FreeCAD.Console.PrintWarning(
                    "Remote connections have no auth token configured — anyone on "
                    "an allowed IP can execute code in FreeCAD. Set one via "
                    "'Set Auth Token' in the FreeCAD MCP menu.\n"
                )
        else:
            FreeCAD.Console.PrintMessage("Remote connections disabled.\n")

        if rpc_server.rpc_server_instance:
            FreeCAD.Console.PrintMessage(
                "Restart the RPC server for changes to take effect.\n"
            )

    def IsActive(self):
        return True


class ConfigureAllowedIPsCommand:
    def GetResources(self):
        return {
            "MenuText": "Configure Allowed IPs",
            "ToolTip": "Set which IP addresses or subnets are allowed to connect to the RPC server.",
        }

    def Activated(self):
        from . import rpc_server
        settings = load_settings()
        current_ips = settings.get("allowed_ips", "127.0.0.1")
        text, ok = QtWidgets.QInputDialog.getText(
            None,
            "Allowed IP Addresses",
            "Enter allowed IP addresses or subnets (comma-separated):\n"
            "Examples: 127.0.0.1, 192.168.1.0/24, 10.0.0.5",
            QtWidgets.QLineEdit.Normal,
            current_ips,
        )
        if ok and text.strip():
            valid, errors = validate_allowed_ips(text.strip())
            if errors:
                QtWidgets.QMessageBox.warning(
                    None,
                    "Invalid IP Configuration",
                    "The following errors were found:\n\n"
                    + "\n".join(f"• {e}" for e in errors)
                    + ("\n\nOnly valid entries will be saved."
                       if valid else "\n\nNo valid entries found. Settings not changed."),
                )
            if not valid:
                FreeCAD.Console.PrintWarning("Allowed IPs not changed — no valid entries.\n")
                return
            normalised = ", ".join(valid)
            settings["allowed_ips"] = normalised
            if not _persist_settings(settings):
                return
            FreeCAD.Console.PrintMessage(
                f"Allowed IPs updated to: {normalised}\n"
            )
            if rpc_server.rpc_server_instance:
                FreeCAD.Console.PrintMessage(
                    "Restart the RPC server for changes to take effect.\n"
                )
        else:
            FreeCAD.Console.PrintMessage("Allowed IPs not changed.\n")

    def IsActive(self):
        return True


class SetAuthTokenCommand:
    def GetResources(self):
        return {
            "MenuText": "Set Auth Token",
            "ToolTip": "Set the shared-secret token clients must present to connect. Blank disables authentication.",
        }

    def Activated(self):
        from . import rpc_server
        settings = load_settings()
        current = settings.get("auth_token", "")
        text, ok = QtWidgets.QInputDialog.getText(
            None,
            "Auth Token",
            "Enter the auth token clients must present (leave blank to disable\n"
            "authentication). The MCP server passes it via --auth-token or the\n"
            "FREECAD_MCP_TOKEN environment variable.",
            QtWidgets.QLineEdit.Normal,
            current,
        )
        if not ok:
            FreeCAD.Console.PrintMessage("Auth token not changed.\n")
            return
        settings["auth_token"] = text.strip()
        if not _persist_settings(settings):
            return
        if settings["auth_token"]:
            FreeCAD.Console.PrintMessage("Auth token set — clients must authenticate.\n")
        else:
            FreeCAD.Console.PrintMessage("Auth token cleared — authentication disabled.\n")
        if rpc_server.rpc_server_instance:
            FreeCAD.Console.PrintMessage(
                "Restart the RPC server for changes to take effect.\n"
            )

    def IsActive(self):
        return True


class ToggleAutoStartCommand:
    def GetResources(self):
        settings = load_settings()
        return {
            "MenuText": "Auto-Start Server",
            "ToolTip": "Automatically start the RPC server when FreeCAD launches.",
            "Checkable": bool(settings.get("auto_start_rpc", False)),
        }

    def Activated(self, checked=0):
        settings = load_settings()
        settings["auto_start_rpc"] = bool(checked)
        if not _persist_settings(settings):
            return

        if settings["auto_start_rpc"]:
            FreeCAD.Console.PrintMessage(
                "MCP RPC server will start automatically on next FreeCAD launch.\n"
            )
        else:
            FreeCAD.Console.PrintMessage(
                "MCP RPC server auto-start disabled.\n"
            )

    def IsActive(self):
        return True


def register_commands() -> None:
    FreeCADGui.addCommand("Start_RPC_Server", StartRPCServerCommand())
    FreeCADGui.addCommand("Stop_RPC_Server", StopRPCServerCommand())
    FreeCADGui.addCommand("Toggle_Auto_Start", ToggleAutoStartCommand())
    FreeCADGui.addCommand("Toggle_Remote_Connections", ToggleRemoteConnectionsCommand())
    FreeCADGui.addCommand("Configure_Allowed_IPs", ConfigureAllowedIPsCommand())
    FreeCADGui.addCommand("Set_Auth_Token", SetAuthTokenCommand())


def schedule_toggle_sync() -> None:
    """Compatibility no-op; toggle state is initialized by ``GetResources``.

    FreeCAD treats the presence of the ``Checkable`` resource as making an
    action checkable and uses its boolean value as the action's initial checked
    state. Loading the saved setting in ``GetResources`` therefore avoids any
    delayed QAction lookup or workbench activation at startup.
    """
